package moduletest;

/**
 *
 * @author maria
 */
public class ModuleTest {


    public static void main(String[] args) {
        
        // Task 1
        Module test = new Module(); // Create a Module object using the default constructor
        test.print(); // Call the print() method to show the properties of the test object
        
        // Task 2
        // Create a Module object using the parameterised constructor
        Module programming = new Module("CP40061E", "Programming", 4, 100, 0);
        programming.print(); // Call the print() method to show the properties of the programming object
        
        //Task 3
        // Create a new Module object using the default constructor, and then use
        // set methods to set its properties
        Module maths = new Module();
        maths.setCode("CP40063E");
        maths.setTitle("Mathematics for Computing");
        maths.setLevel(4);
        maths.setCwWeight(100);
        maths.setExWeight(0);
        // Call the print() method to show the properties of the maths object
        maths.print();
        
        // Task 4
        // Test the access methods
        System.out.println("Print properties of maths object:");
        System.out.println("Module code: " + maths.getCode());
        System.out.println("Module title: " + maths.getTitle());
        System.out.println("Module level: " + maths.getLevel());
        System.out.println("Module coursework weighting: " + maths.getCwWeight() + "%");
        System.out.println("Module exam weighting: " + maths.getExWeight() + "%");

        // Task 5
        // Create a new object using the default constructor
        // Then call the ask() method so the user can enter the module details
        // and call the print() method to check the method worked correctly
        Module myModule = new Module();
        myModule.ask();
        myModule.print();
    }
    
}
