package moduletest;

import java.util.Scanner;

/**
 *
 * @author maria
 */
public class Module {
    
    //Task 1
    // Define class properties
    private String code;    // Stores the module code
    private String title;   // Stores the module title
    private int level;      // Stores the module level
    private int cwWeight;   // Stores the module's coursework weighting as a percentage
    private int exWeight;   // Stores the module's exam weighting as a percentage
    
    // Task 1
    // Define a default constructor
    public Module() // default constructor
    {
        code = "??????";
        title = "No Title";
        level = 0;
        cwWeight = 0;
        exWeight = 0;
    }
    
    // Define a print method to help test the class
    public void print()
    {
        System.out.println("Module code: " + code);
        System.out.println("Module Title: " + title);
        System.out.println("Module level: " + level);
        System.out.println("Module coursework weighting: " + cwWeight + "%");
        System.out.println("Module exam weighting: " + exWeight + "%");
        
    }
    
    // Task 2
    // Define a parameterised constructor
    public Module(String moduleCode, String moduleTitle, int moduleLevel, int moduleCwWeight, int moduleExWeight)
    {   // Parameterised constructor - initilises class properties to the values passed as arguments
        code = moduleCode;
        title = moduleTitle;
        level = moduleLevel;
        cwWeight = moduleCwWeight;
        exWeight = moduleExWeight;
    }
    

    // Task 3
    // Define set methods to set the class properties individually
    public void setCode(String moduleCode)
    {
        code = moduleCode;
    }
    public void setTitle(String moduleTitle)
    {
        title = moduleTitle;
    }    
    public void setLevel(int moduleLevel)
    {
        level = moduleLevel;
    }
    public void setCwWeight(int moduleCwWeight)
    {
        cwWeight = moduleCwWeight;
    }
    public void setExWeight(int moduleExWeight)
    {
        exWeight = moduleExWeight;
    }
    
    // Task 4
    // Define access methods to get each of the properties of the class
    public String getCode()
    {
        return code;
    }
    public String getTitle()
    {
        return title;
    }
    public int getLevel()
    {
        return level;
    }
    public int getCwWeight()
    {
        return cwWeight;
    }
    public int getExWeight()
    {
        return exWeight;
    }
    
    // Task 5
    // Define a method to prompt the user to enter details for a module, and store them in the object properties
    public void ask()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the module code: ");
        code = input.nextLine();
        System.out.println("Please enter the module title: ");
        title = input.nextLine();
        System.out.println("Please enter the module level: ");
        level = input.nextInt();
        System.out.println("Please enter the module coursework weighting: ");
        cwWeight = input.nextInt();
        System.out.println("Please enter the module exam weighting: ");
        exWeight = input.nextInt();        
    }
    
}
